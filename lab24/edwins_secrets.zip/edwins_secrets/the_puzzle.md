The Puzzle
-----------
The text file you've just found contians the words feeling, fee, coffee, feelers, and feel in 
what seems to be a random order. You'll need to find and replace each word to find the secret!

	Start by reading in the file as a String.
	Each word corresponds to a different character:
		feel -> .
		feeling -> O
		fee -> space
		coffee -> $
		feelers -> "
	After you've replaced each word, find the character that is repeated 48 times.
	Split the string by this character, and then print out each line of the resulting
	String array in order, on a separate line.

Once you've figured out the secret, you should show it to your TA.
(You might need to copy paste the output into a text file and zoom out).
